package me.fivevl.gamblingbot

import net.dv8tion.jda.api.entities.User
import java.sql.Connection
import java.sql.DriverManager
import javax.sql.rowset.CachedRowSet
import javax.sql.rowset.RowSetProvider

object Database {
    private lateinit var connection: Connection
    private const val host = "[REDACTED]"
    private const val port = "[REDACTED]"
    private const val database = "[REDACTED]"
    private const val username = "[REDACTED]"
    private const val password = "[REDACTED]"
    fun init() {
        connection = DriverManager.getConnection("jdbc:mysql://$host:$port/$database", username, password)
        update("create table if not exists `balance` (`userid` BIGINT not null, `balance` BIGINT not null default 1000, primary key (`userid`))")
        update("create table if not exists `daily` (`userid` BIGINT not null, `time` BIGINT not null default 0, primary key (`userid`))")
    }
    private fun prepareStatement(sql: String) = connection.prepareStatement(sql)
    fun update(sql: String) = prepareStatement(sql).executeUpdate()
    fun query(sql: String): CachedRowSet {
        val rs = prepareStatement(sql).executeQuery()
        val crs = RowSetProvider.newFactory().createCachedRowSet()
        crs.populate(rs)
        rs.close()
        return crs
    }
    fun User.hasStarted(): Boolean {
        val rs = query("select * from `balance` where `userid` = $idLong")
        return rs.next()
    }
    fun User.start() {
        update("insert into `balance` values ($idLong, default)")
        update("insert into `daily` values ($idLong, default)")
    }
    fun User.reset() {
        update("update `balance` set `balance` = 1000 where `userid` = $idLong")
    }
    fun User.getBalance(): Long {
        val rs = query("select * from `balance` where `userid` = $idLong")
        return if (rs.next()) rs.getLong("balance") else 0
    }
    private fun User.setBalance(amount: Long) {
        update("update `balance` set `balance` = $amount where `userid` = $idLong")
    }
    fun User.removeBalance(amount: Long) {
        this.setBalance(this.getBalance() - amount)
    }
    fun User.addBalance(amount: Long) {
        this.setBalance(this.getBalance() + amount)
    }
    fun User.getDaily(): Long {
        val rs = query("select * from `daily` where `userid` = $idLong")
        return if (rs.next()) rs.getLong("time") else 0
    }
    fun User.setDaily() {
        update("update `daily` set `time` = ${System.currentTimeMillis() + (24*60*60*1000)} where `userid` = $idLong")
    }
}