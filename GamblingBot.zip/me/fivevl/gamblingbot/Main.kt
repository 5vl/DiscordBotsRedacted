package me.fivevl.gamblingbot

import net.dv8tion.jda.api.JDA
import net.dv8tion.jda.api.JDABuilder
import net.dv8tion.jda.api.interactions.commands.OptionType
import net.dv8tion.jda.api.requests.GatewayIntent
import java.util.*

object Main {
    val bets = HashMap<Long, Long>()
    private lateinit var jda: JDA
    @JvmStatic
    fun main(args: Array<String>) {
        val builder = JDABuilder.createDefault("[REDACTED]")
        builder.enableIntents(EnumSet.allOf(GatewayIntent::class.java))
        jda = builder.build()
        jda.awaitReady()
        Database.init()
        registerCommands()
    }
    private fun registerCommands() {
        jda.upsertCommand("balance", "Check your or another users balance").addOption(OptionType.USER, "user", "Who's balance do you want to check", false).queue()
        jda.upsertCommand("daily", "Claim your daily coins").queue()
        jda.upsertCommand("gamble", "Gamble your coins").addOption(OptionType.INTEGER, "amount", "How much do you want to gamble", true).queue()
        jda.upsertCommand("leaderboard", "Check the leaderboard").queue()
        jda.upsertCommand("pay", "Pay another user").addOption(OptionType.USER, "user", "Who do you want to pay", true).addOption(OptionType.INTEGER, "amount", "How much do you want to pay", true).queue()
        jda.upsertCommand("reset", "Reset your account").queue()
        jda.addEventListener(CommandHandler())
        jda.addEventListener(GambleHandler())
    }
}