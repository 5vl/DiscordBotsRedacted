package me.fivevl.gamblingbot

import me.fivevl.gamblingbot.Database.addBalance
import me.fivevl.gamblingbot.Database.getBalance
import me.fivevl.gamblingbot.Database.getDaily
import me.fivevl.gamblingbot.Database.hasStarted
import me.fivevl.gamblingbot.Database.removeBalance
import me.fivevl.gamblingbot.Database.setDaily
import me.fivevl.gamblingbot.Database.start
import net.dv8tion.jda.api.EmbedBuilder
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent
import net.dv8tion.jda.api.hooks.ListenerAdapter
import net.dv8tion.jda.api.interactions.components.buttons.Button
import java.awt.Color
import java.util.*
import kotlin.collections.ArrayList

class CommandHandler : ListenerAdapter() {
    override fun onSlashCommandInteraction(e: SlashCommandInteractionEvent) {
        if (!e.user.hasStarted()) {
            e.user.start()
        }
        when (e.name) {
            "balance" -> balance(e)
            "daily" -> daily(e)
            "gamble" -> gamble(e)
            "leaderboard" -> leaderboard(e)
            "pay" -> pay(e)
            "reset" -> reset(e)
        }
    }

    private fun embedBuilder(title: String, description: String): EmbedBuilder {
        return embedBuilder(title, description, Color(8, 138, 242))
    }

    private fun embedBuilder(title: String, description: String, color: Color): EmbedBuilder {
        return EmbedBuilder().setColor(color).setTitle(title).setDescription(description)
    }

    private fun balance(e: SlashCommandInteractionEvent) {
        if (e.options.isNotEmpty()) {
            val user = e.options[0].asUser
            e.replyEmbeds(embedBuilder("Balance", "<@${user.idLong}> has ${user.getBalance()} coins.").build()).queue()
        } else {
            e.replyEmbeds(embedBuilder("Balance", "You have ${e.user.getBalance()} coins.").build()).queue()
        }
    }

    private fun daily(e: SlashCommandInteractionEvent) {
        if (e.user.getDaily() > System.currentTimeMillis()) {
            e.user.addBalance(15000)
            e.user.setDaily()
            e.replyEmbeds(embedBuilder("Daily", "You have claimed your daily gift of 15000 coins. You now have ${e.user.getBalance()} coins.", Color.GREEN).build()).queue()
        } else {
            e.replyEmbeds(embedBuilder("Daily", "You have already claimed your daily coins.", Color.RED).build()).queue()
        }
    }

    private fun gamble(e: SlashCommandInteractionEvent) {
        if (Main.bets.containsKey(e.user.idLong)) {
            e.replyEmbeds(embedBuilder("Gamble", "You already have a bet running.", Color.RED).build()).queue()
            return
        }
        val amount = e.options[0].asLong
        if (amount < 100) {
            e.replyEmbeds(embedBuilder("Gamble", "You can only gamble over 100 coins!", Color.RED).build()).queue()
            return
        }
        if (amount > e.user.getBalance()) {
            e.replyEmbeds(embedBuilder("Gamble", "You don't have enough coins to gamble that much!", Color.RED).build()).queue()
            return
        }
        e.user.removeBalance(amount)
        Main.bets[e.user.idLong] = amount
        e.replyEmbeds(embedBuilder("Gamble", "What game do you want to play?").build()).addActionRow(Button.primary("highlow", "Higher or lower"), Button.primary("fiftyfifty", "50/50")).queue()
    }

    private fun leaderboard(e: SlashCommandInteractionEvent) {
        val sj = StringJoiner("\n")
        val rs = Database.query("select * from `balance` order by `balance` desc limit 10")
        var i = 0
        while (rs.next()) {
            i++
            sj.add("**$i:** <@${rs.getLong("userid")}> - ${rs.getLong("balance")}")
        }
        e.replyEmbeds(embedBuilder("Leaderboard", sj.toString()).build()).queue()
    }

    private fun pay(e: SlashCommandInteractionEvent) {
        if (e.options[1].asInt <= 0) {
            e.replyEmbeds(embedBuilder("Pay", "You can't pay nothing!", Color.RED).build()).queue()
            return
        }
        if (e.user.getBalance() - e.options[1].asInt < 0) {
            e.replyEmbeds(embedBuilder("Pay", "You don't have enough coins to pay that much!", Color.RED).build()).queue()
            return
        }
        if (!e.options[0].asUser.hasStarted()) {
            e.replyEmbeds(embedBuilder("Pay", "That user has not started their account yet.", Color.RED).build()).queue()
            return
        }
        e.user.removeBalance(e.options[1].asLong)
        e.options[0].asUser.addBalance(e.options[1].asLong)
        e.replyEmbeds(embedBuilder("Pay", "You have paid <@${e.options[0].asUser.idLong}> ${e.options[1].asLong} coins. You now have ${e.user.getBalance()} coins.").build()).queue()

    }

    private val resetMap = ArrayList<Long>()
    private fun reset(e: SlashCommandInteractionEvent) {
        Database.update("DELETE FROM daily WHERE userid = ${e.user.idLong}")
        Database.update("DELETE FROM balance WHERE userid = ${e.user.idLong}")
        e.user.start()
        e.replyEmbeds(embedBuilder("Reset", "Your account has been reset.", Color.GREEN).build()).queue()
        /*if (resetMap.contains(e.user.idLong)) {
            e.user.reset()
            e.replyEmbeds(embedBuilder("Reset", "Your account has been reset.", Color.GREEN).build()).queue()
            resetMap.remove(e.user.idLong)
        } else {
            resetMap.add(e.user.idLong)
            e.replyEmbeds(embedBuilder("Reset", "Are you sure you want to reset your account? This action is irreversible. Type `/reset` again within 20 seconds to confirm.", Color.RED).build()).queue()
            Thread {
                Thread.sleep(20000)
                if (resetMap.contains(e.user.idLong)) {
                    e.messageChannel.sendMessageEmbeds(embedBuilder("Reset", "<@${e.user.idLong}>'s reset has timed out.", Color.RED).build()).queue()
                    resetMap.remove(e.user.idLong)
                }
            }.start()
        }*/
    }
}