package me.fivevl.gamblingbot

import me.fivevl.gamblingbot.Database.addBalance
import me.fivevl.gamblingbot.Database.getBalance
import net.dv8tion.jda.api.EmbedBuilder
import net.dv8tion.jda.api.events.interaction.component.ButtonInteractionEvent
import net.dv8tion.jda.api.hooks.ListenerAdapter
import net.dv8tion.jda.api.interactions.components.buttons.Button
import java.awt.Color
import kotlin.random.Random

class GambleHandler : ListenerAdapter() {
    override fun onButtonInteraction(e: ButtonInteractionEvent) {
        if (!Main.bets.containsKey(e.user.idLong)) {
            e.reply("You've already used this game! Please create a new one.").setEphemeral(true).queue()
            return
        }
        when (e.button.id) {
            "highlow" -> {highlow(e); return}
            "fiftyfifty" -> {fiftyfifty(e); return}
        }
        if (!e.button.id!!.contains(e.user.id)) {
            e.reply("You can't play someone else's game!").setEphemeral(true).queue()
            return
        }
        if (e.button.id!!.startsWith("hl")) {
            hl(e)
        }
        if (e.button.id!!.startsWith("ff")) {
            ff(e)
        }
    }

    private fun embedBuilder(title: String, description: String): EmbedBuilder {
        return embedBuilder(title, description, Color(8, 138, 242))
    }

    private fun embedBuilder(title: String, description: String, color: Color): EmbedBuilder {
        return EmbedBuilder().setColor(color).setTitle(title).setDescription(description)
    }

    private fun highlow(e: ButtonInteractionEvent) {
        e.replyEmbeds(embedBuilder("Higher or lower", "Is the number higher or lower than ${Random.nextInt(1, 100)} (1-100)").build()).addActionRow(
            Button.primary("hl${e.user.id}high", "Higher"), Button.primary("hl${e.user.id}low", "Lower")).queue()
    }
    private fun fiftyfifty(e: ButtonInteractionEvent) {
        e.replyEmbeds(embedBuilder("50/50", "50/50. Which side do you choose?").build()).addActionRow(
            Button.primary("ff${e.user.id}left", "Left"), Button.primary("ff${e.user.id}right", "Right")).queue()
    }

    private fun hl(e: ButtonInteractionEvent) {
        if (Random.nextBits(1) != 0) {
            val extra = Random.nextFloat() + 0.5
            val addBal = ((Main.bets[e.user.idLong]!! * extra) + Main.bets[e.user.idLong]!!).toInt()
            e.user.addBalance(addBal.toLong())
            e.replyEmbeds(embedBuilder("Higher-lower", "You won $addBal coins! That's ${(extra * 100).toInt()}% extra! You now have ${e.user.getBalance()} coins.", Color.GREEN).build()).queue()
        } else {
            e.replyEmbeds(embedBuilder("Higher-lower", "You lost! You lost ${Main.bets[e.user.idLong]} coins. You now have ${e.user.getBalance()}", Color.RED).build()).queue()
        }
        Main.bets.remove(e.user.idLong)
    }

    private fun ff(e: ButtonInteractionEvent) {
        if (Random.nextBits(1) != 0) {
            val extra = Random.nextFloat() + 0.5
            val addBal = ((Main.bets[e.user.idLong]!! * extra) + Main.bets[e.user.idLong]!!).toInt()
            e.user.addBalance(addBal.toLong())
            e.replyEmbeds(embedBuilder("50/50", "You won $addBal coins! That's ${(extra * 100).toInt()}% extra! You now have ${e.user.getBalance()} coins.", Color.GREEN).build()).queue()
        } else {
            e.replyEmbeds(embedBuilder("50/50", "You lost! You lost ${Main.bets[e.user.idLong]} coins. You now have ${e.user.getBalance()}", Color.RED).build()).queue()
        }
        Main.bets.remove(e.user.idLong)
    }
}