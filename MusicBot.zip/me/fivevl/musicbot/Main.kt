package me.fivevl.musicbot

import com.sedmelluq.discord.lavaplayer.player.AudioLoadResultHandler
import com.sedmelluq.discord.lavaplayer.player.AudioPlayerManager
import com.sedmelluq.discord.lavaplayer.player.DefaultAudioPlayerManager
import com.sedmelluq.discord.lavaplayer.source.AudioSourceManagers
import com.sedmelluq.discord.lavaplayer.tools.FriendlyException
import com.sedmelluq.discord.lavaplayer.track.AudioPlaylist
import com.sedmelluq.discord.lavaplayer.track.AudioTrack
import me.fivevl.musicbot.listeners.SlashCommandListener
import net.dv8tion.jda.api.JDA
import net.dv8tion.jda.api.JDABuilder
import net.dv8tion.jda.api.Permission
import net.dv8tion.jda.api.entities.Activity
import net.dv8tion.jda.api.entities.Guild
import net.dv8tion.jda.api.entities.TextChannel
import net.dv8tion.jda.api.events.interaction.SlashCommandEvent
import net.dv8tion.jda.api.interactions.commands.OptionType
import net.dv8tion.jda.api.managers.AudioManager

object Main {
    @JvmStatic
    fun main(args: Array<String>) {
        val builder = JDABuilder.createDefault("[REDACTED]")
        builder.addEventListeners(SlashCommandListener())
        builder.setActivity(Activity.listening("music"))
        Main.jda = builder.build()
        Main.jda!!.awaitReady()
        Main.updateCommands()
    }

    lateinit var jda: JDA

    fun updateCommands() {
        val guild = jda.getGuildById([REDACTED])
        guild.upsertCommand("play", "Play music!").addOption(OptionType.STRING, "url", "Input the youtube URL here!", true).queue()
        guild.upsertCommand("stop", "Stop the music!").queue()
        guild.upsertCommand("skip", "Skip the song.").queue()
        guild.upsertCommand("queue", "See what's in the queue!").queue()
        guild.upsertCommand("shuffle", "Toggle the shuffle!").queue()
        guild.upsertCommand("np", "Check what's currently playing!").queue()
        guild.upsertCommand("pause", "Pause/unpause the music!").queue()
        guild.upsertCommand("repeat", "Repeat the current track!").queue()
    }

    private lateinit var playerManager: AudioPlayerManager
    private lateinit var musicManagers: MutableMap<Long, GuildMusicManager>

    init {
        musicManagers = HashMap()
        playerManager = DefaultAudioPlayerManager()
        AudioSourceManagers.registerRemoteSources(playerManager)
        AudioSourceManagers.registerLocalSource(playerManager)
    }

    fun getGuildAudioPlayer(guild: Guild): GuildMusicManager {
        val guildId: Long = guild.id.toLong()
        var musicManager = musicManagers[guildId]
        if (musicManager == null) {
            musicManager = GuildMusicManager(playerManager!!)
            musicManagers[guildId] = musicManager
        }
        guild.audioManager.sendingHandler = musicManager.getSendHandler()
        return musicManager
    }

    fun loadAndPlay(channel: TextChannel, trackUrl: String, e: SlashCommandEvent) {
        val musicManager = getGuildAudioPlayer(channel.guild)
        playerManager?.loadItemOrdered(musicManager, trackUrl, object : AudioLoadResultHandler {
            override fun trackLoaded(track: AudioTrack) {
                play(channel.guild, musicManager, track, e, "Adding to queue ${track.info.title}")
            }

            override fun playlistLoaded(playlist: AudioPlaylist) {
                var firstTrack = playlist.selectedTrack
                if (firstTrack == null) {
                    firstTrack = playlist.tracks[0]
                }
                var msg = "Adding to queue ${firstTrack!!.info.title} (From playlist ${playlist.name})"
                if (playlist.isSearchResult) {
                    msg = "Adding to queue ${firstTrack.info.title} (${playlist.name})"
                }
                play(channel.guild, musicManager, firstTrack, e, msg)
            }

            override fun noMatches() {
                e.reply("Nothing found by $trackUrl").setEphemeral(true).queue()
            }

            override fun loadFailed(exception: FriendlyException) {
                e.reply("Could not play: " + exception.message).setEphemeral(true).queue()
            }
        })
    }

    private fun play(guild: Guild, musicManager: GuildMusicManager, track: AudioTrack?, e: SlashCommandEvent, message: String) {
        connectToFirstVoiceChannel(guild.audioManager, e, message)
        musicManager.scheduler!!.queue(track!!)
    }

    fun skipTrack(channel: TextChannel, e: SlashCommandEvent) {
        val musicManager = getGuildAudioPlayer(channel.guild)
        musicManager.scheduler!!.nextTrack()
        e.reply("Skipped to next track.").setEphemeral(true).queue()
    }

    private fun connectToFirstVoiceChannel(audioManager: AudioManager, e: SlashCommandEvent, message: String) {
        if (!e.member?.voiceState?.inVoiceChannel()!!) {
            e.reply("You're not in a voice channel!").setEphemeral(true).queue()
            return
        }
        val voiceChannel = e.member?.voiceState?.channel
        if (!e.guild?.selfMember?.hasPermission(voiceChannel!!, Permission.VOICE_CONNECT)!!) {
            e.reply("I do not have permission to join this channel!").setEphemeral(true).queue()
            return
        }
        e.reply(message).setEphemeral(true).queue()
        audioManager.openAudioConnection(voiceChannel)
    }
}
