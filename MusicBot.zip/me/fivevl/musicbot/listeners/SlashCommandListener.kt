package me.fivevl.musicbot.listeners

import me.fivevl.musicbot.Main
import net.dv8tion.jda.api.events.interaction.SlashCommandEvent
import net.dv8tion.jda.api.hooks.ListenerAdapter
import java.util.StringJoiner
import java.util.concurrent.LinkedBlockingQueue

class SlashCommandListener : ListenerAdapter() {
    override fun onSlashCommand(e: SlashCommandEvent) {
        when (e.name) {
            "play" -> playCommand(e)
            "stop" -> stopCommand(e)
            "skip" -> skipCommand(e)
            "queue" -> queueCommand(e)
            "shuffle" -> shuffleCommand(e)
            "np" -> npCommand(e)
            "pause" -> pauseCommand(e)
            "repeat" -> repeatCommand(e)
        }
    }

    private fun playCommand(e: SlashCommandEvent) {
        var str = e.getOption("url")!!.asString
        if (!str.startsWith("https://") && !str.startsWith("http://")) {
            str = "s:${str}"
        }
        if (str.startsWith("s:")) {
            str = str.replaceFirst("s:", "ytsearch:")
        }
        Main.loadAndPlay(e.textChannel, str, e)
    }

    private fun stopCommand(e: SlashCommandEvent) {
        Main.getGuildAudioPlayer(e.jda.getGuildById([REDACTED])!!).player?.stopTrack()
        Main.getGuildAudioPlayer(e.jda.getGuildById([REDACTED])!!).scheduler?.queue = LinkedBlockingQueue()
        e.guild?.audioManager?.closeAudioConnection()
        e.reply("Stopped playing music!").setEphemeral(true).queue()
    }

    private fun skipCommand(e: SlashCommandEvent) {
        Main.skipTrack(e.textChannel, e)
    }

    private fun queueCommand(e: SlashCommandEvent) {
        val joiner = StringJoiner("\n")
        val gm = Main.getGuildAudioPlayer(e.jda.getGuildById([REDACTED])!!)
        if (gm.scheduler?.queue?.isEmpty()!!) {
            e.reply("There are currently no songs in the queue!").setEphemeral(true).queue()
            return
        }
        joiner.add("Shuffle is currently set to ${gm.scheduler?.shuffle}.")
        var count = 0
        for (song in gm.scheduler?.queue!!) {
            count++
            if (count == 10) break
            joiner.add("$count: ${song.info.title} - ${song.info.author}")
        }
        e.reply(joiner.toString()).setEphemeral(true).queue()
    }

    private fun shuffleCommand(e: SlashCommandEvent) {
        val sch = Main.getGuildAudioPlayer(e.jda.getGuildById([REDACTED])!!).scheduler
        sch?.shuffle = !sch?.shuffle!!
        e.reply("Set shuffle to ${sch.shuffle}!").setEphemeral(true).queue()
    }

    private fun npCommand(e: SlashCommandEvent) {
        val track = Main.getGuildAudioPlayer(e.jda.getGuildById([REDACTED])!!).player?.playingTrack?.info
        e.reply("Now playing: ${track?.title} - ${track?.author}").setEphemeral(true).queue()
    }

    private fun pauseCommand(e: SlashCommandEvent) {
        val player = Main.getGuildAudioPlayer(e.jda.getGuildById([REDACTED])!!).player
        player?.isPaused = !player?.isPaused!!
        if (player.isPaused) {
            e.reply("Paused the music!").setEphemeral(true).queue()
        } else {
            e.reply("Unpaused the music!").setEphemeral(true).queue()
        }
    }

    private fun repeatCommand(e: SlashCommandEvent) {
        val gm = Main.getGuildAudioPlayer(e.jda.getGuildById([REDACTED])!!)
        val sch = gm.scheduler
        if (sch?.repeat == null) {
            sch?.repeat = gm.player?.playingTrack
            e.reply("Now on repeat: ${sch?.repeat?.info?.title} - ${sch?.repeat?.info?.author}").setEphemeral(true).queue()
        } else {
            sch.repeat = null
            e.reply("Stopped repeat!").setEphemeral(true).queue()
        }
    }
}