package me.fivevl.musicbot

import com.sedmelluq.discord.lavaplayer.player.AudioPlayer
import com.sedmelluq.discord.lavaplayer.player.event.AudioEventAdapter
import com.sedmelluq.discord.lavaplayer.track.AudioTrack
import com.sedmelluq.discord.lavaplayer.track.AudioTrackEndReason
import java.util.*
import java.util.concurrent.BlockingQueue
import java.util.concurrent.LinkedBlockingQueue


class TrackScheduler(player: AudioPlayer?) : AudioEventAdapter() {
    private var player: AudioPlayer? = null
    var queue: BlockingQueue<AudioTrack>? = null
    var shuffle = false
    var repeat: AudioTrack? = null

    init {
        this.player = player
        queue = LinkedBlockingQueue()
    }

    fun queue(track: AudioTrack) {
        if (!player!!.startTrack(track, true)) {
            queue!!.offer(track)
        }
    }

    fun nextTrack() {
        if (repeat != null) {
            player!!.startTrack(repeat!!.makeClone(), false)
            return
        }
        if (shuffle) {
            val random = Random()
            val nr = random.nextInt(queue!!.size - 1)
            player!!.startTrack(queue!!.elementAt(nr), false)
            queue!!.remove(queue!!.elementAt(nr))
            return
        }
        player!!.startTrack(queue!!.poll(), false)
    }

    override fun onTrackEnd(player: AudioPlayer?, track: AudioTrack?, endReason: AudioTrackEndReason) {
        if (endReason.mayStartNext) {
            nextTrack()
        }
    }
}