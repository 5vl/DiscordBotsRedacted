package me.fivevl.musictrivia

import com.sedmelluq.discord.lavaplayer.player.AudioLoadResultHandler
import com.sedmelluq.discord.lavaplayer.player.AudioPlayer
import com.sedmelluq.discord.lavaplayer.player.AudioPlayerManager
import com.sedmelluq.discord.lavaplayer.player.DefaultAudioPlayerManager
import com.sedmelluq.discord.lavaplayer.source.AudioSourceManagers
import com.sedmelluq.discord.lavaplayer.tools.FriendlyException
import com.sedmelluq.discord.lavaplayer.track.AudioPlaylist
import com.sedmelluq.discord.lavaplayer.track.AudioTrack
import net.dv8tion.jda.api.JDA
import net.dv8tion.jda.api.JDABuilder
import net.dv8tion.jda.api.entities.Activity
import net.dv8tion.jda.api.requests.GatewayIntent

object Main {
    @JvmStatic
    fun main(args: Array<String>) {
        val builder = JDABuilder.createDefault("[REDACTED]")
        builder.enableIntents(GatewayIntent.GUILD_MESSAGES)
        builder.addEventListeners(Handler())
        builder.setActivity(Activity.listening("/start"))
        jda = builder.build()
        jda.awaitReady()
        init()
        updateCommands()
        Database.setConnection("[REDACTED]", [REDACTED], "[REDACTED]", "[REDACTED]", "[REDACTED]")
    }
    lateinit var jda: JDA
    fun updateCommands() {
        val guild = jda!!.getGuildById([REDACTED])!!
        guild.upsertCommand("start", "Starts the music trivia game").queue()
        guild.upsertCommand("stop", "Stops the game and leaves the voice channel.").queue()
    }

    private var playerManager: AudioPlayerManager? = null
    private var player: AudioPlayer? = null

    fun init() {
        playerManager = DefaultAudioPlayerManager()
        player = playerManager!!.createPlayer()
        AudioSourceManagers.registerRemoteSources(playerManager)
        AudioSourceManagers.registerLocalSource(playerManager)
        val guild = jda!!.getGuildById([REDACTED])!!
        guild.audioManager.sendingHandler = AudioPlayerSendHandler(player)
    }

    fun play(trackUrl: String): String {
        var msg = ""
        playerManager?.loadItemOrdered(player, trackUrl, object : AudioLoadResultHandler {
            override fun trackLoaded(track: AudioTrack) {
                player!!.startTrack(track, true)
            }
            override fun playlistLoaded(p0: AudioPlaylist?) {}
            override fun noMatches() {}
            override fun loadFailed(exception: FriendlyException) {
                msg = "Could not play: " + exception.message
            }
        })
        return msg
    }
    fun leave() {
        player?.stopTrack()
        jda!!.getGuildById([REDACTED])!!.audioManager.closeAudioConnection()
    }
}
