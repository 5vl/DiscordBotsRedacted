package me.fivevl.musictrivia

import net.dv8tion.jda.api.Permission
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent
import net.dv8tion.jda.api.events.interaction.component.SelectMenuInteractionEvent
import net.dv8tion.jda.api.events.message.MessageReceivedEvent
import net.dv8tion.jda.api.hooks.ListenerAdapter
import net.dv8tion.jda.api.interactions.components.selections.SelectMenu
import java.util.*

class Handler : ListenerAdapter() {
    var genre: String? = null
    var awnser: String? = null
    override fun onSlashCommandInteraction(e: SlashCommandInteractionEvent) {
        when (e.name) {
            "start" -> startCommand(e)
            "stop" -> stopCommand(e)
        }
    }

    override fun onSelectMenuInteraction(e: SelectMenuInteractionEvent) {
        if (genre == null && e.selectMenu.id == "menu:genre") {
            genre = e.selectedOptions[0].value
            e.reply("You have selected the genre: ${e.selectedOptions[0].label}").queue()
            e.message.delete().queue()
            val rand = Random()
            val rs = if (genre == "any") {
                Database.query("SELECT * FROM music")
            } else {
                Database.query("SELECT * FROM music WHERE (genre = '$genre')")
            }
            if (!rs.last()) {
                e.channel.sendMessage("There are no songs in this genre!").queue()
                e.message.delete().queue()
                return
            }
            val size = rs.row
            rs.beforeFirst()
            rs.absolute(rand.nextInt(size + 1) + 1)
            val msg = Main.play(rs.getString("url"))
            if (msg != "") {
                e.channel.sendMessage(msg).queue()
                return
            }
            if (rand.nextInt(2) == 0) {
                awnser = rs.getString("title").lowercase()
                e.channel.sendMessage("What is the title of the current playing song?").queue()
            } else {
                awnser = rs.getString("artist").lowercase()
                e.channel.sendMessage("What is the artist of the current playing song?").queue()
            }
        }
    }

    override fun onMessageReceived(e: MessageReceivedEvent) {
        if (e.message.contentDisplay.lowercase() == awnser) {
            e.message.reply("Correct!").queue()
            awnser = null
            genre = null
            Main.leave()
            return
        }
    }
    private fun startCommand(e: SlashCommandInteractionEvent) {
        if (e.member?.voiceState?.channel == null) {
            e.reply("You're not in a voice channel!").queue()
            return
        }
        val voiceChannel = e.member?.voiceState?.channel
        if (!e.guild?.selfMember?.hasPermission(voiceChannel!!, Permission.VOICE_CONNECT)!!) {
            e.reply("I do not have permission to join your channel!").queue()
            return
        }
        val menu = SelectMenu.create("menu:genre").setPlaceholder("Genre...")
            .addOption("Any", "any")
            .addOption("Pop", "pop")
            .addOption("Kpop", "kpop")
            .addOption("Hardstyle", "hardstyle")
            .addOption("80s", "80s")
            .addOption("10s", "10s")
            .addOption("20s", "20s")
            .addOption("Rap", "rap")
            .addOption("Hiphop", "hiphop")
            .addOption("Metal", "metal")
            .addOption("Rock", "rock")
            .addOption("EDM", "edm").setRequiredRange(1, 1).build()
        e.reply("Please pick your genre below.").addActionRow(menu).queue()
        e.guild!!.audioManager.openAudioConnection(voiceChannel)
    }

    private fun stopCommand(e: SlashCommandInteractionEvent) {
        Main.leave()
        e.reply("Stopped the game and left the voice channel!").queue()
    }
}