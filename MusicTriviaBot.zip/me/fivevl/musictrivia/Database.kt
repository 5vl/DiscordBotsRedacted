package me.fivevl.musictrivia

import java.sql.Connection
import java.sql.DriverManager
import java.sql.PreparedStatement
import javax.sql.rowset.CachedRowSet
import javax.sql.rowset.RowSetProvider

object Database {
    private var conn: Connection? = null
    fun setConnection(host: String, port: Int, user: String, pass: String, db: String) {
        conn = DriverManager.getConnection("jdbc:mysql://$host:$port/$db", user, pass)
    }

    private fun prepareStatement(sql: String): PreparedStatement {
        return conn!!.prepareStatement(sql)
    }

    fun update(sql: String) {
        prepareStatement(sql).executeUpdate()
    }

    fun query(sql: String): CachedRowSet {
        val rs = RowSetProvider.newFactory().createCachedRowSet()
        val q = prepareStatement(sql).executeQuery()
        rs.populate(q)
        q.close()
        return rs
    }
}