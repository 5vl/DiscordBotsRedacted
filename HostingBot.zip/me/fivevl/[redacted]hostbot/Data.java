package me.fivevl.[redacted]hostbot;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

public class Data {
    String id;
    String username;
    String email;
    String detail;
    JsonObject attributes;
    JsonArray errors;
    String identifier;
    String startup;
    String code;
    JsonArray data;
}
