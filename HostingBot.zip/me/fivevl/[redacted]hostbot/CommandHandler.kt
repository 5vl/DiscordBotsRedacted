package me.fivevl.[redacted]hostbot

import com.google.gson.Gson
import com.google.gson.JsonObject
import net.dv8tion.jda.api.Permission
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent
import net.dv8tion.jda.api.hooks.ListenerAdapter
import kotlin.random.Random

class CommandHandler : ListenerAdapter() {
    override fun onSlashCommandInteraction(e: SlashCommandInteractionEvent) {
        when (e.name) {
            "admin" -> admin(e)
            else -> e.reply("Unknown command").setEphemeral(true).queue()
        }
    }

    private fun admin(e: SlashCommandInteractionEvent) {
        if (!e.member!!.permissions.contains(Permission.ADMINISTRATOR)) {
            e.reply("You do not have permission to use this command").setEphemeral(true).queue()
            return
        }
        when (e.subcommandName) {
            "createuser" -> {
                val user = e.getOption("username")!!.asString
                val email = e.getOption("email")!!.asString
                val pass = Random.nextInt(10000000, 99999999).toString()
                val data = Pterodactyl.createUser(email, user, pass)
                if (data.errors != null) {
                    val d2 = Gson().fromJson(data.errors[0], Data::class.java)
                    e.reply("Error: `${d2.detail}`").setEphemeral(true).queue()
                    return
                }
                e.reply("Created user `${data.username}` with email `${data.email}`, password `$pass` and ID `${data.id}`.").queue()
            }
            "createtestserver" -> {
                val user = e.getOption("user")!!.asUser
                val userid = e.getOption("userid")!!.asInt
                val env = JsonObject()
                env.addProperty("SERVER_JARFILE", "server.jar")
                env.addProperty("BUILD_NUMBER", "latest")
                val data = Pterodactyl.createServer("${user.name}'s Test Server", userid, 1, 3, "ghcr.io/pterodactyl/yolks:java_17", env, Pterodactyl.limitsObject(5120, -1, 25600, 200), Pterodactyl.featureLimitsObject(0, 1, 1))
                if (data.errors != null) {
                    val d2 = Gson().fromJson(data.errors[0], Data::class.java)
                    e.reply("Error: `${d2.detail}`").setEphemeral(true).queue()
                    return
                }
                e.reply("Server created! You can access it at: https://panel.[REDACTED URL]/${data.identifier}").queue()
            }
            "getuserid" -> {
                val email = e.getOption("email")!!.asString
                e.reply("User ID: `${Pterodactyl.getUserByEmail(email)}` for email `$email`.").setEphemeral(true).queue()
            }
            else -> e.reply("Unknown subcommand").setEphemeral(true).queue()
        }
    }
}