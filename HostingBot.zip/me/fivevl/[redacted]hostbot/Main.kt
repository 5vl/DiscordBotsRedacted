package me.fivevl.[redacted]hostbot

import net.dv8tion.jda.api.JDA
import net.dv8tion.jda.api.JDABuilder
import net.dv8tion.jda.api.OnlineStatus
import net.dv8tion.jda.api.entities.Activity
import net.dv8tion.jda.api.interactions.commands.OptionType
import net.dv8tion.jda.api.interactions.commands.build.SubcommandData
import net.dv8tion.jda.api.requests.GatewayIntent

object Main {
    private const val token = "[REDACTED TOKEN]"
    private lateinit var jda: JDA
    @JvmStatic
    fun main(args: Array<String>) {
        val builder = JDABuilder.createDefault(token)
        builder.addEventListeners(CommandHandler())
        builder.enableIntents(GatewayIntent.GUILD_MEMBERS, GatewayIntent.GUILD_MESSAGES, GatewayIntent.MESSAGE_CONTENT)
        builder.setActivity(Activity.listening("your commands"))
        builder.setStatus(OnlineStatus.DO_NOT_DISTURB)
        jda = builder.build()
        jda.awaitReady()
        val guild = jda.getGuildById([REDACTED GUILD ID])!!
        guild.upsertCommand("admin", "Admin commands")
            .addSubcommands(SubcommandData("createuser", "Create user")
                .addOption(OptionType.STRING, "username", "User to create", true)
                .addOption(OptionType.STRING, "email", "Email for user", true))
            .addSubcommands(SubcommandData("createtestserver", "Create a test server")
                .addOption(OptionType.USER, "user", "User to create server for", true)
                .addOption(OptionType.INTEGER, "userid", "User ID to create server for", true))
            .addSubcommands(SubcommandData("getuserid", "Get the user ID by email")
                .addOption(OptionType.STRING, "email", "Email to get ID for", true))
            .queue()
    }
}