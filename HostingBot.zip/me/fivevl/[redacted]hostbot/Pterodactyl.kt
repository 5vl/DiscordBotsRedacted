package me.fivevl.[redacted]hostbot

import com.google.gson.Gson
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody


object Pterodactyl {
    private const val url = "https://panel.[REDACTED URL]"

    @Suppress("SpellCheckingInspection")
    private const val token = "[REDACTED TOKEN]"

    private fun buildRequest(path: String): Request.Builder {
        return Request.Builder()
            .url(url + path)
            .header("Authorization", "Bearer $token")
            .header("Accept", "application/json")
            .header("Content-Type", "application/json")
    }

    private fun doRequest(request: Request): String {
        return OkHttpClient.Builder().build().newCall(request).execute().body!!.string()
    }

    private fun doGetRequest(path: String): String {
        return doRequest(buildRequest(path).get().build())
    }

    private fun doPostRequest(path: String, json: JsonObject): String {
        return doRequest(buildRequest(path).post(json.toString().toRequestBody("application/json".toMediaType())).build())
    }

    private fun getData(response: String): Data {
        val d1 = Gson().fromJson(response, Data::class.java)
        if (d1.errors != null) {
            return d1
        }
        return Gson().fromJson(d1.attributes, Data::class.java)
    }

    fun createUser(email: String, username: String, password: String): Data {
        val json = JsonObject()
        json.addProperty("email", email)
        json.addProperty("username", username)
        json.addProperty("password", password)
        json.addProperty("first_name", username)
        json.addProperty("last_name", username)
        val res = doPostRequest("/api/application/users", json)
        return getData(res)
    }


    fun createServer(name: String, userId: Int, nestId: Int, eggId: Int, dockerImage: String, environment: JsonObject, limits: JsonObject, featureLimits: JsonObject): Data {
        val json = JsonObject()
        json.addProperty("name", name)
        json.addProperty("user", userId)
        json.addProperty("egg", eggId)
        json.addProperty("docker_image", dockerImage)
        json.addProperty("startup", getDefaultStartup(nestId, eggId))
        json.add("environment", environment)
        json.add("limits", limits)
        json.add("feature_limits", featureLimits)
        val deploy = JsonObject()
        val array = JsonArray()
        array.add(1)
        deploy.add("locations", array)
        deploy.addProperty("dedicated_ip", false)
        deploy.add("port_range", JsonArray())
        json.add("deploy", deploy)
        val res = doPostRequest("/api/application/servers", json)
        return getData(res)
    }

    private fun getDefaultStartup(nestId: Int, eggId: Int): String {
        val res = doGetRequest("/api/application/nests/$nestId/eggs/$eggId")
        val data = getData(res)
        if (data.errors != null) return Gson().fromJson(data.errors[0], Data::class.java).code
        return data.startup
    }

    fun limitsObject(ram: Int, swap: Int, disk: Int, cpu: Int): JsonObject {
        val limits = JsonObject()
        limits.addProperty("memory", ram)
        limits.addProperty("swap", swap)
        limits.addProperty("disk", disk)
        limits.addProperty("cpu", cpu)
        limits.addProperty("io", 500)
        return limits
    }

    fun featureLimitsObject(databases: Int, allocations: Int, backups: Int): JsonObject {
        val featureLimits = JsonObject()
        featureLimits.addProperty("databases", databases)
        featureLimits.addProperty("allocations", allocations)
        featureLimits.addProperty("backups", backups)
        return featureLimits
    }

    fun getUserByEmail(email: String): String {
        val res = doRequest(buildRequest("/api/application/users?search=$email").get().build())
        val d1 = Gson().fromJson(res, Data::class.java)
        if (d1.errors != null) {
            return Gson().fromJson(d1.attributes, Data::class.java).detail
        }
        return Gson().fromJson(Gson().fromJson(d1.data[0], Data::class.java).attributes, Data::class.java).id
    }
}