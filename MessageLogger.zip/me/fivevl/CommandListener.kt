package me.fivevl

import net.dv8tion.jda.api.entities.GuildChannel
import net.dv8tion.jda.api.entities.User
import net.dv8tion.jda.api.events.interaction.SlashCommandEvent
import net.dv8tion.jda.api.hooks.ListenerAdapter
import java.util.*
import javax.sql.rowset.CachedRowSet
import kotlin.collections.HashMap

class CommandListener : ListenerAdapter() {
    override fun onSlashCommand(e: SlashCommandEvent) {
        e.deferReply(true).queue()
        if (e.name == "wordcount") {
            val time = e.getOption("timespan")?.asString ?: return
            val user = e.getOption("user")?.asUser ?: return
            val word = e.getOption("word")?.asString ?: return
            val channelOption = e.getOption("in")
            var channel: GuildChannel? = null
            if (channelOption != null) {
                channel = channelOption.asGuildChannel
            }
            val totalTime = getTotalTime(time, e)
            if (totalTime == 0L) { return }
            val rs: CachedRowSet? = if (channel == null) Database.query("SELECT * FROM messages WHERE(TIME > $totalTime AND USERID = '${user.id}')")
            else Database.query("SELECT * FROM messages WHERE(TIME > $totalTime AND USERID = '${user.id}' AND CHANNELID = '${channel.id}')")
            if (rs == null) {
                if (channel == null) {e.hook.sendMessage("${user.asMention} has said the word '$word' 0 times.").setEphemeral(true).queue()}
                else {e.hook.sendMessage("${user.asMention} has said the word '$word' 0 times in #${channel.asMention}.").setEphemeral(true).queue()}
                return
            }
            var count = 0
            while (rs.next()) {
                val msg = rs.getString("MESSAGE")
                if (msg.contains(word)) count++
            }
            rs.close()
            if (channel == null) {e.hook.sendMessage("${user.asMention} has said the word '$word' $count times.").setEphemeral(true).queue()}
            else {e.hook.sendMessage("${user.asMention} has said the word '$word' $count times in ${channel.asMention}.").setEphemeral(true).queue()}
        }

        if (e.name == "topwords") {
            val time = e.getOption("timespan")?.asString ?: return
            val word = e.getOption("word")?.asString ?: return
            val channelOption = e.getOption("in")
            var channel: GuildChannel? = null
            if (channelOption != null) {
                channel = channelOption.asGuildChannel
            }
            val totalTime = getTotalTime(time, e)
            if (totalTime == 0L) { return }
            val rs: CachedRowSet? = if (channel == null) Database.query("SELECT * FROM messages WHERE(TIME > $totalTime)")
            else Database.query("SELECT * FROM messages WHERE(TIME > $totalTime AND CHANNELID = '${channel.id}')")
            if (rs == null) {
                if (channel == null) {e.hook.sendMessage("The word '$word' has not been said.").setEphemeral(true).queue()}
                else {e.hook.sendMessage("The word '$word' has not been said in #${channel.asMention}.").setEphemeral(true).queue()}
                return
            }
            val counts = HashMap<Long, Long>()
            while (rs.next()) {
                val message = rs.getString("MESSAGE")
                if (message.contains(word)) {
                    val userId = rs.getString("USERID").toLong()
                    if (!counts.contains(userId)) {
                        counts[userId] = 1L
                    } else {
                        counts[userId] = counts[userId]?.plus(1)!!
                    }
                }
            }
            val builder = StringJoiner("\n")
            if (channel != null) {
                builder.add("Top 10 of '$word' in ${channel.asMention}:")
            } else {
                builder.add("Top 10 of '$word':")
            }
            val itr = TreeMap(counts).values.iterator()
            var max = 0
            while(itr.hasNext()) {
                if (max == 10) break
                val key = itr.next()
                e.jda.retrieveUserById(rs.getString("USERID")).queue {
                        user: User -> builder.add("${user.asMention} said $word ${counts[key]} times.")
                }
                max++
            }
            e.hook.sendMessage(builder.toString()).setEphemeral(true).queue()
        }
    }
    private fun getTotalTime(time: String, e: SlashCommandEvent): Long {
        var totalTime = 0L
        try {
            if (time.contains("d")) totalTime += time.split("d")[0].toLong() * 1000 * 60 * 60 * 24
            if (time.contains("m")) totalTime += time.split("m")[0].toLong() * 1000 * 60 * 60 * 24 * 30
            if (time.contains("y")) totalTime += time.split("y")[0].toLong() * 1000 * 60 * 60 * 24 * 365
        } catch (ex: NumberFormatException) {
            e.hook.sendMessage("That is not a correct time format. Example: '1d' would be 1 day, '1m' 1 month and '1y' 1 year.").setEphemeral(true).queue()
            return 0L
        }
        return System.currentTimeMillis() - totalTime
    }
}