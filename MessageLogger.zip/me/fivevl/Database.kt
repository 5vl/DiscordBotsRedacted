package me.fivevl

import java.sql.*
import javax.sql.rowset.CachedRowSet
import javax.sql.rowset.RowSetProvider


object Database {
    private var connection: Connection? = null
    fun initializeConnection() {
        connection = DriverManager.getConnection("jdbc:mysql://[REDACTED]:[REDACTED]/[REDACTED]", "[REDACTED]", "[REDACTED]")
    }

    fun prepareStatement(sql: String): PreparedStatement {
        if (connection == null) {
            initializeConnection()
        }
        return connection!!.prepareStatement(sql)
    }

    fun query(sql: String): CachedRowSet? {
        var rs: CachedRowSet? = null
        try {
            val rs2: ResultSet? = prepareStatement(sql).executeQuery()
            rs = RowSetProvider.newFactory().createCachedRowSet()
            rs.populate(rs2)
            rs2?.close()
        } catch (e: SQLException) {
            e.printStackTrace()
        }
        return rs
    }
}