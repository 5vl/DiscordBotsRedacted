package me.fivevl

import net.dv8tion.jda.api.events.message.guild.GuildMessageReceivedEvent
import net.dv8tion.jda.api.hooks.ListenerAdapter

class MessageListener : ListenerAdapter() {
    override fun onGuildMessageReceived(e: GuildMessageReceivedEvent) {
        if (e.author.isBot) return
        val ps = Database.prepareStatement("INSERT INTO messages(TIME, USERID, CHANNELID, MESSAGE) VALUES('${System.currentTimeMillis()}', '${e.author.id}', ${e.channel.id}, '?')")
        ps.setString(1, e.message.contentDisplay)
        ps.execute()
    }
}