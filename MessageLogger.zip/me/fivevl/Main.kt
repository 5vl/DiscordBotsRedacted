package me.fivevl

import net.dv8tion.jda.api.JDA
import net.dv8tion.jda.api.JDABuilder
import net.dv8tion.jda.api.OnlineStatus
import net.dv8tion.jda.api.interactions.commands.OptionType


object Main {
    private var jda: JDA? = null
    @JvmStatic
    fun main(args: Array<String>) {
        val builder = JDABuilder.createDefault("[REDACTED]")
        builder.setStatus(OnlineStatus.OFFLINE)
        builder.addEventListeners(MessageListener(), CommandListener())
        jda = builder.build()
        jda!!.awaitReady()
        if (args.size == 1 && args[0] == "update") updateCommands()
        Database.initializeConnection()
    }

    private fun updateCommands() {
        jda?.upsertCommand("wordcount", "Display the word count of a word.")
            ?.addOption(OptionType.STRING, "timespan", "Set the timespan that you want.", true)
            ?.addOption(OptionType.USER, "user", "Set the wanted user", true)
            ?.addOption(OptionType.STRING, "word", "Set the wanted word", true)
            ?.addOption(OptionType.CHANNEL, "in", "Set the channel", false)
            ?.queue()
        jda?.upsertCommand("topwords", "Display the top word count.")
            ?.addOption(OptionType.STRING, "timespan", "Set the timespan that you want.", true)
            ?.addOption(OptionType.STRING, "word", "Set the wanted word", true)
            ?.addOption(OptionType.CHANNEL, "in", "Set the channel", false)
            ?.queue()
        println("Updated commands!")
    }

}
